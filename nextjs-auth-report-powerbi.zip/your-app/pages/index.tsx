import { signIn } from "next-auth/react";

export default function Home() {
  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">Login</h1>
      <button onClick={() => signIn()} className="bg-blue-500 text-white px-4 py-2 rounded">
        Sign in
      </button>
    </div>
  );
}
