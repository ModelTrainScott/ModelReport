import { useSession, getSession } from "next-auth/react";
import Chart from "../components/Chart";

export default function Dashboard() {
  const { data: session } = useSession();

  if (!session) return <p>Loading...</p>;

  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">Welcome {session.user?.name}</h1>
      <Chart />
    </div>
  );
}

export async function getServerSideProps(context: any) {
  const session = await getSession(context);
  if (!session) {
    return { redirect: { destination: "/", permanent: false } };
  }
  return { props: { session } };
}
