import { useEffect, useRef } from "react";
import { models, Embed, service } from "powerbi-client";

export default function Chart() {
  const reportRef = useRef(null);

  useEffect(() => {
    const embedConfiguration = {
      type: "report",
      id: "your-report-id",
      embedUrl: "https://app.powerbi.com/reportEmbed?reportId=your-report-id&groupId=your-group-id",
      accessToken: "your-embed-token",
      tokenType: models.TokenType.Embed,
      settings: {
        panes: {
          filters: { visible: false },
          pageNavigation: { visible: true }
        },
        navContentPaneEnabled: true
      }
    };

    const powerbiService = new service.Service(powerbi.factories.hpmFactory, powerbi.factories.wpmpFactory, powerbi.factories.routerFactory);
    powerbiService.embed(reportRef.current, embedConfiguration);

    return () => {
      powerbiService.reset(reportRef.current);
    };
  }, []);

  return (
    <div>
      <h2 className="text-xl mb-4">Power BI Report</h2>
      <div ref={reportRef} style={{ height: "600px", width: "100%" }}></div>
    </div>
  );
}
